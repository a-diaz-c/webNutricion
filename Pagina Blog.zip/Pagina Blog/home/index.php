<?php 
require '../functions/home/select_main.php';
require 'header.php';
$res = getArticles();
?>
	<!-- Fin menu -->

	<!-- Carousel -->
	<div class="container col-xl-8">
		<div class="row"> 
			<div class="col-lg-12">
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
				  <ol class="carousel-indicators">
				    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
				    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
				    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
				  </ol>
				  <div class="carousel-inner">
				  	<?php
				  	$i=0;
				  	while($row = $res->fetch_array(MYSQLI_ASSOC) and ($i<3)){
				  		$dir = "../" ;
				  		$dir .= substr($row['img'], 36);
				  		if($i==0)
				  			echo '<div class="carousel-item active">';
				  		else
				  			echo '<div class="carousel-item">';
				  		$i++;
				  	 ?>
				    
				      <a href="blog_post.php?id=<?php echo $row['articulo_id'] ?>"><img class="d-block w-100" src="<?php echo $dir ?>" alt="First slide" id=""></a>
				      <div class="carousel-caption">
				      	<a class="text-light" href="blog_post.php?id=<?php echo $row['articulo_id'] ?>"><p class="text-light"><?php echo $row['titulo']; ?></p></a>
				      </div>
				  </div>
				<?php } ?>
				  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
				    <span class="sr-only">Anterior</span>
				  </a>
				  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				    <span class="carousel-control-next-icon" aria-hidden="true"></span>
				    <span class="sr-only">Siguiente</span>
				  </a>
				</div>
			</div>
		</div>
	</div>
	<!-- fin Carousel-->

	<!-- texto -->

	<div class="container">
		<div class="row mb-3">
			<div class="card bg-light">
				<div class="card-header">¿Quiénes somos?</div>	
				<div class="card-body">
					<p class="card-text text-justify">
						Somos un equipo profesional y multidisciplinario enfocados en el área de la salud y deporte, donde ofrecemos programas de orientación nutrimental y entrenamiento de acuerdo a las necesidades de mejorar: el estado físico y/o el estado de salud de cada persona, contando con nutricionistas y entrenadores deportivos físicos capacitados y actualizados en las ramas académicas, brindando un servicio más completo, vinculando en todo momento el ejercicio y planes alimenticios.
					</p>
					<p class="card-text">
						Ofrecemos:
					</p>
					<ol>
						<li type="disc"> 
							<p class="card-text text-justify">
								Evaluaciones de composición corporal Y evaluaciones de peso (brindando un % a cada una y promediando tu composición corporal)
							</p>
							<ul>
								<li>% muscular y de grasa</li>
								<li>Nivel de masa grasa por pliegues</li>
								<li>Nivel de masa magra por pliegues y circunferencias</li>
								<li>IMC (índice de masa corporal)</li>
								<li>Peso ideal</li>
							</ul>
						</li>
						<br>
						<li type="disc">
							<p>
								Medidas antropométricas
							</p>
							<ul>
								<li>Peso</li>
								<li>Talla</li>
								<li>Pliegues</li>
								<li>Circunferencias (cintura/cadera)</li>
								<li>Diámetro óseo</li>
							</ul>
						</li>
						<br>
						<li type="disc">Grasa segmentada</li>
						<li type="disc">Somatotipo</li>
						<li type="disc">Agua corporal total </li>
						<li type="disc">Glucosa en sangre</li>
						<li type="disc">Presión arterial</li>
						<li type="disc">Saturación de oxígeno de la hemoglobina arterial</li>
						<li type="disc">Gráfica del control de peso periódicamente </li>
						<li type="disc">Gasto energético total </li>
						<li type="disc">Menú de 5 días</li>
						<li type="disc">Guía de equivalentes</li>
						<li type="disc">Guía de alimentos trampas</li>
						<li type="disc">Número telefónico de nutricionista</li>
						<li type="disc">Plan periodizado de entrenamiento de pesas</li>
						<li type="disc">Acondicionamiento físico funcional</li>
						<li type="disc">Clases de MMA (Artes Marciales Mixtas)</li>
						<li type="disc">Kick boxing</li>
						<li type="disc">Sumisión</li>
						<li type="disc">Defensa personal </li>								
					</ol>
				</div>
			</div>
		</div>

		<div class="row mt-3 justify-content-between">		
			<div class="card bg-light mb-3 col-md-6 col-xl-6 col-sm-12">
			  <div class="card-header">Misión</div>
			  <div class="card-body">
			    <p class="card-text text-justify">Ser una organización reconocida a nivel nacional e internacional, por brindar servicios especializados en mejora de rendimiento deportivo, salud y estética corporal dirigida a hombres y mujeres interesados en tener un buen estado físico y de salud, mediante  consultas nutricionales y entrenamientos periodizados y estructurada para cada persona, basados en sus objetivos, características físicas, anatómicas y gustos alimenticios.</p>
			  </div>
			</div>
			<div class="card bg-light mb-3 col-md-6 col-xl-6 col-sm-12">
			  <div class="card-header">Visión</div>
			  <div class="card-body">
			    <p class="card-text text-justify">Consolidar Reconocimiento a nivel nacional e internacional, por generar mejoras físicas y de salud, que permitan superar las expectativas de nuestros clientes, por la calidad de servicio, y valides académica.</p>
			  </div>
			</div>			
		</div>
	</div>
</div>
	<!-- fin texto-->
<?php require 'footer.php' ?>