    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link active" href="index.php">
                  <span data-feather="home"></span>
                  Inicio<span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="post.php">
                  <span data-feather="file-text"></span>
                  Nuevo Artículo<span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="categoria.php">
                  <span data-feather="file-text"></span>
                  Categorías<span class="sr-only">(current)</span>
                </a>
              </li>           
              <!-- <li class="nav-item">
                <a class="nav-link active" href="archivos.php">
                  <span data-feather="file-text"></span>
                  Subir Archivo<span class="sr-only">(current)</span>
                </a>
              </li>-->
              <li class="nav-item">
                <a class="nav-link active" href="curriculum.php">
                  <span data-feather="file-text"></span>
                  Curriculum<span class="sr-only">(current)</span>
                </a>
              </li>                                        
            </ul>
          </div>
        </nav>