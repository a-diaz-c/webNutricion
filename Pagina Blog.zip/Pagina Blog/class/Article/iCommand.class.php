<?php 

interface iCommand{
	function exec();
}

 ?>