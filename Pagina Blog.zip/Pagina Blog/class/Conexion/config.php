<?php 

define('CONF_DB_HOTS','localhost');
define('CONF_DB_USER','root');
define('CONF_DB_PASS','12345');
define('CONF_DB_DATABASE','db_blog');
define('CONF_DB_CHARSET','utf8');

 ?>