<?php 
require 'require.php';

function validateId(){
	if(empty($id) || !is_numeric($id) || $id <= 0){
		return false;
	}
	return true;
}
function getArticles($id){
	$article = new Article(new Conexion);
	$article->setArticleId($id);
	$cliente = new Client($article);
	$res = $cliente->operate('select');
	$result_array = $res->fetch_array(MYSQLI_ASSOC);
	return json_encode($result_array);
}

/*if(isset($_POST['id']))
	$id = $_POST['id'];
else
	$id = '';*/

$id = $_POST['id'];

if(validateId($_POST['id'])) exit('id_inválido');
echo getArticles($id);

 ?>