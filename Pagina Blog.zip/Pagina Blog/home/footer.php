	<!-- footer -->
<footer class="page-footer font-small bg-dark">

  <!-- Copyright -->
  <div class="text-light">
  	<div class="container">
  		<h5 class="font-weight-bold">Ubicación</h5>
  	</div>
  	<div class="container">
  	<p>Calle Tampico #56, esquina con Nautla col. Progreso</p>
  	</div>
  </div>
  <!-- Copyright -->

</footer>
</body>
	<!-- footer -->
</body>
	<script src="../js/jquery-3.3.1.min.js"></script>
	<script src="../js/popper.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
  <script src="../js/comentario/comentario.js"></script>
</html>